<?php
/**
 * Plugin Name: OMS Porudžbine
 * Description: Interni OMS kao WordPress/WooCommerce plugin sa CSV-vezanim dropdown listama gde ulica određuje mesto.
 * Version: 0.5.4
 * Author: Slobodan Zarić
 * Requires PHP: 7.4
 * Requires at least: 6.0
 * WC requires at least: 8.0
 */

if (!defined('ABSPATH')) { exit; }

// === Konstante ===
define('OMSP_VERSION', '0.5.4');
define('OMSP_SLUG', 'oms-porudzbine');
define('OMSP_PATH', plugin_dir_path(__FILE__));
define('OMSP_URL', plugin_dir_url(__FILE__));
define('OMSP_OPT_ACCOUNTS', 'omsp_api_accounts');

// === Error handling ===
function omsp_log_error($message, $data = null) {
    if (defined('WP_DEBUG') && WP_DEBUG) {
        error_log('OMSP Plugin Error: ' . $message . ($data ? ' | Data: ' . print_r($data, true) : ''));
    }
}

// === Forsiraj IPv4 za sve outbound cURL pozive (izbegava IPv6 probleme) ===
add_action('http_api_curl', function($handle) {
    if (defined('CURL_IPRESOLVE_V4')) {
        @curl_setopt($handle, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
    }
});

// === Aktivacija ===
register_activation_hook(__FILE__, 'omsp_activation_hook');
function omsp_activation_hook() {
    try {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // Tabela adresnica
        $labels = $wpdb->prefix . 'omsp_labels';
        $sql = "CREATE TABLE IF NOT EXISTS $labels (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            order_id BIGINT UNSIGNED NULL,
            source VARCHAR(50) NOT NULL DEFAULT 'local',
            api_account VARCHAR(60) NULL,
            api_sent TINYINT(1) NOT NULL DEFAULT 0,
            api_response MEDIUMTEXT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            recipient_name VARCHAR(190) NOT NULL,
            address_line1 VARCHAR(190) NOT NULL,
            address_line2 VARCHAR(190) NULL,
            city VARCHAR(120) NOT NULL,
            postal_code VARCHAR(20) NULL,
            phone VARCHAR(40) NULL,
            notes TEXT NULL,
            cod_amount DECIMAL(10,2) NULL,
            house_no VARCHAR(20) NULL,
            municipality_id INT UNSIGNED NULL,
            place_id INT UNSIGNED NULL,
            street_id INT UNSIGNED NULL,
            addr_valid TINYINT(1) NOT NULL DEFAULT 0,
            addr_error VARCHAR(255) NULL,
            PRIMARY KEY (id),
            KEY order_id (order_id),
            KEY api_account (api_account),
            KEY created_at (created_at),
            KEY api_sent (api_sent)
        ) $charset;";
        dbDelta($sql);

        // BEX referentne tabele
        $municip = $wpdb->prefix . 'omsp_bex_municipalities';
        $places  = $wpdb->prefix . 'omsp_bex_places';
        $streets = $wpdb->prefix . 'omsp_bex_streets';
        dbDelta("CREATE TABLE IF NOT EXISTS $municip ( id INT UNSIGNED PRIMARY KEY, name VARCHAR(190) NOT NULL, INDEX(name) ) $charset;");
        dbDelta("CREATE TABLE IF NOT EXISTS $places ( id INT UNSIGNED PRIMARY KEY, municipality_id INT UNSIGNED NOT NULL, name VARCHAR(190) NOT NULL, zip VARCHAR(10) NULL, INDEX(municipality_id), INDEX(name) ) $charset;");
        dbDelta("CREATE TABLE IF NOT EXISTS $streets ( id INT UNSIGNED PRIMARY KEY, place_id INT UNSIGNED NOT NULL, name VARCHAR(190) NOT NULL, INDEX(place_id), INDEX(name) ) $charset;");

        if (get_option(OMSP_OPT_ACCOUNTS) === false) add_option(OMSP_OPT_ACCOUNTS, array());
        if (get_option('omsp_api_secret', false) === false) add_option('omsp_api_secret', wp_generate_password(32, false));
    } catch (Exception $e) {
        omsp_log_error('Activation failed', $e->getMessage());
        wp_die('Plugin aktivacija nije uspela: ' . $e->getMessage());
    }
}

// === Helperi (opšti) ===
function omsp_get_accounts() {
    $accounts = get_option(OMSP_OPT_ACCOUNTS, array());
    return is_array($accounts) ? array_values($accounts) : array();
}
function omsp_get_account_by_id($id) {
    if (empty($id)) return null;
    foreach (omsp_get_accounts() as $a) {
        if (isset($a['id']) && $a['id'] === (string)$id) return $a;
    }
    return null;
}
function omsp_account_name($id) {
    $a = omsp_get_account_by_id((string)$id);
    return isset($a['name']) ? $a['name'] : null;
}
function omsp_get_default_accounts() {
    $site = null; $manual = null;
    foreach (omsp_get_accounts() as $a) {
        if (!empty($a['is_default_site'])) $site = $a;
        if (!empty($a['is_default_manual'])) $manual = $a;
    }
    return array($site, $manual);
}
function omsp_normalize_phone($raw) {
    $raw = (string)$raw;
    if ($raw === '') return '';
    $s = preg_replace('/[^\d+]/', '', $raw);
    if (strpos($s, '00') === 0) { $s = '+' . substr($s, 2); }
    if (preg_match('/^0(6\d+)/', $s, $m)) { $s = '+381' . $m[1]; }
    $s = preg_replace('/^\+3810/', '+381', $s);
    $check = preg_replace('/[^\d]/', '', $s);
    if (strlen($check) < 8) { return $raw; }
    return $s;
}
if (!function_exists('omsp_remove_bom')) {
    function omsp_remove_bom($str) {
        if (substr($str, 0, 3) === pack('CCC', 0xEF, 0xBB, 0xBF)) return substr($str, 3);
        return $str;
    }
}

function omsp_extract_street_parts($raw_street) {
    $normalized = trim(preg_replace('/\s+/', ' ', (string)$raw_street));
    if ($normalized === '') {
        return array('', '');
    }

    $name = $normalized;
    $house = '';

    if (preg_match('/\s+(\d+[\p{L}0-9\/\-]*)$/u', $normalized, $match)) {
        $house = $match[1];
        $name = trim(substr($normalized, 0, -strlen($match[0])));
    }

    if ($house === '' && preg_match('/\bBB\b/i', $normalized)) {
        $house = 'BB';
    }

    if ($name === '') {
        $name = $normalized;
    }

    return array($name, $house);
}

function omsp_normalize_street_key($name) {
    $key = function_exists('remove_accents') ? remove_accents($name) : $name;
    $key = strtolower($key);
    $key = preg_replace('/[^a-z0-9\s]/u', ' ', $key);
    $key = preg_replace('/\s+/', ' ', $key);
    return trim($key);
}

function omsp_line_looks_like_phone($line) {
    $digits = preg_replace('/[^0-9+]/', '', (string)$line);
    if ($digits === '') {
        return false;
    }
    $plus_pos = strpos($digits, '+');
    if ($plus_pos !== false && $plus_pos > 0) {
        $digits = substr($digits, 0, $plus_pos) . substr($digits, $plus_pos + 1);
    }
    $numbers_only = preg_replace('/\D/', '', $digits);
    if (strlen($numbers_only) < 6) {
        return false;
    }
    return true;
}

function omsp_line_seems_like_street($line) {
    $lower = strtolower(trim((string)$line));
    if ($lower === '') {
        return false;
    }
    if (preg_match('/\d/', $lower)) {
        return true;
    }
    if (preg_match('/\bul\.?\b|\bulica\b/', $lower)) {
        return true;
    }
    if (preg_match('/\bbb\b/', $lower)) {
        return true;
    }
    return false;
}

function omsp_manual_normalize_token($value) {
    $value = function_exists('remove_accents') ? remove_accents($value) : $value;
    $value = strtolower((string)$value);
    $value = preg_replace('/[^a-z0-9\s]/u', ' ', $value);
    $value = preg_replace('/\s+/', ' ', $value);
    return trim($value);
}

function omsp_manual_get_reference_data() {
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }

    $places_raw = omsp_load_csv_places();
    $streets_raw = omsp_load_csv_streets();
    $municipalities_raw = omsp_load_csv_municipalities();

    $municipalities_by_norm = array();
    foreach ($municipalities_raw as $municipality_row) {
        $norm = omsp_manual_normalize_token($municipality_row['name']);
        if ($norm === '') {
            continue;
        }
        $municipalities_by_norm[$norm] = array(
            'id' => (string)$municipality_row['id'],
            'name' => $municipality_row['name'],
        );
    }

    $places_by_id = array();
    $places_by_zip = array();
    $places_list = array();
    foreach ($places_raw as $place_row) {
        $place_id = (string)$place_row['id'];
        $norm_name = omsp_manual_normalize_token($place_row['name']);
        $norm_municipality = omsp_manual_normalize_token($place_row['municipality']);
        $municipality_id = 0;
        if ($norm_municipality !== '' && isset($municipalities_by_norm[$norm_municipality])) {
            $municipality_id = (int)$municipalities_by_norm[$norm_municipality]['id'];
        }
        $record = array(
            'id' => $place_id,
            'name' => $place_row['name'],
            'norm_name' => $norm_name,
            'zip' => $place_row['zip'],
            'municipality_name' => $place_row['municipality'],
            'municipality_norm' => $norm_municipality,
            'municipality_id' => $municipality_id,
        );
        $places_by_id[$place_id] = $record;
        $places_list[] = $record;
        if ($record['zip'] !== '') {
            if (!isset($places_by_zip[$record['zip']])) {
                $places_by_zip[$record['zip']] = array();
            }
            $places_by_zip[$record['zip']][] = $record;
        }
    }

    $streets_by_place = array();
    $streets_global = array();
    foreach ($streets_raw as $street_row) {
        $place_id = (string)$street_row['place_id'];
        $norm = omsp_manual_normalize_token($street_row['name']);
        $street_record = array(
            'id' => (string)$street_row['id'],
            'name' => $street_row['name'],
            'norm' => $norm,
            'place_id' => $place_id,
        );
        if (!isset($streets_by_place[$place_id])) {
            $streets_by_place[$place_id] = array();
        }
        $streets_by_place[$place_id][] = $street_record;
        $streets_global[] = $street_record;
    }

    $cache = array(
        'places_by_id' => $places_by_id,
        'places_by_zip' => $places_by_zip,
        'places_list' => $places_list,
        'streets_by_place' => $streets_by_place,
        'streets_global' => $streets_global,
        'municipalities_by_norm' => $municipalities_by_norm,
    );

    return $cache;
}

function omsp_manual_split_street_line($line) {
    $line = preg_replace('/\s+/', ' ', trim((string)$line));
    if ($line === '') {
        return array('', '');
    }
    if (preg_match('/^(.*?)[\s,]+((?:\d+[A-Za-z0-9\/-]*)|BB)$/u', $line, $matches)) {
        $street = trim($matches[1]);
        $house = strtoupper(trim($matches[2]));
        return array($street, $house);
    }
    return array($line, '');
}

function omsp_manual_line_could_be_street($line) {
    $line = trim((string)$line);
    if ($line === '') {
        return false;
    }
    if (preg_match('/^A\d+[A-Za-z0-9]*/', $line)) {
        return false;
    }
    if (stripos($line, 'serbia') !== false || stripos($line, 'srbija') !== false) {
        return false;
    }
    if (strpos($line, ' ') === false) {
        return false;
    }
    if (preg_match('/\d/', $line)) {
        return true;
    }
    if (stripos($line, 'ul') !== false || stripos($line, 'bb') !== false) {
        return true;
    }
    return false;
}

function omsp_manual_pick_place($zip, $city_text, $ref) {
    $city_norm = omsp_manual_normalize_token($city_text);
    $matches = array();

    if ($zip !== '' && isset($ref['places_by_zip'][$zip])) {
        $matches = $ref['places_by_zip'][$zip];
    }

    if (!empty($matches) && $city_norm !== '') {
        $exact = array();
        foreach ($matches as $candidate) {
            if ($candidate['norm_name'] === $city_norm) {
                $exact[] = $candidate;
            }
        }
        if (!empty($exact)) {
            $matches = $exact;
        } else {
            $partial = array();
            foreach ($matches as $candidate) {
                if (strpos($candidate['norm_name'], $city_norm) !== false || strpos($city_norm, $candidate['norm_name']) !== false) {
                    $partial[] = $candidate;
                }
            }
            if (!empty($partial)) {
                $matches = $partial;
            }
        }
    }

    if (empty($matches) && $city_norm !== '') {
        foreach ($ref['places_list'] as $candidate) {
            if ($candidate['norm_name'] === $city_norm) {
                $matches[] = $candidate;
            }
        }
    }
    if (empty($matches) && $city_norm !== '') {
        foreach ($ref['places_list'] as $candidate) {
            if (strpos($candidate['norm_name'], $city_norm) !== false || strpos($city_norm, $candidate['norm_name']) !== false) {
                $matches[] = $candidate;
            }
        }
    }

    $best = null;
    $best_score = -INF;
    foreach ($matches as $candidate) {
        $score = 0;
        if ($zip !== '' && $zip === $candidate['zip']) {
            $score += 50;
        }
        if ($city_norm !== '') {
            if ($candidate['norm_name'] === $city_norm) {
                $score += 40;
            } elseif (strpos($candidate['norm_name'], $city_norm) !== false || strpos($city_norm, $candidate['norm_name']) !== false) {
                $score += 20;
            }
        }
        if ($score > $best_score) {
            $best_score = $score;
            $best = $candidate;
        }
    }

    $status = 'not_found';
    if ($best) {
        if (count($matches) > 1) {
            $status = 'ambiguous';
        } else {
            $status = 'ok';
        }
    }

    return array(
        'selected' => $best,
        'matches' => $matches,
        'status' => $status,
        'zip' => $zip,
        'city_input' => $city_text,
        'city_norm' => $city_norm,
    );
}

function omsp_manual_match_street($street_line, $place_record, $ref) {
    $street_line = trim((string)$street_line);
    list($street_name, $house_no) = omsp_manual_split_street_line($street_line);
    $street_norm = omsp_manual_normalize_token($street_name);

    $candidates = array();
    if ($place_record && isset($ref['streets_by_place'][$place_record['id']])) {
        $candidates = $ref['streets_by_place'][$place_record['id']];
    } else {
        $candidates = $ref['streets_global'];
    }

    $matches = array();
    foreach ($candidates as $street) {
        if ($street_norm === '') {
            continue;
        }
        $score = 0;
        if ($street['norm'] === $street_norm) {
            $score = 200;
        } elseif (strpos($street['norm'], $street_norm) !== false || strpos($street_norm, $street['norm']) !== false) {
            $score = 120;
        }
        if ($score <= 0) {
            continue;
        }
        $place_info = $ref['places_by_id'][$street['place_id']] ?? null;
        $matches[] = array(
            'street_id' => $street['id'],
            'street_name' => $street['name'],
            'place_id' => $street['place_id'],
            'place_name' => $place_info ? $place_info['name'] : '',
            'zip' => $place_info ? $place_info['zip'] : '',
            'municipality' => $place_info ? $place_info['municipality_name'] : '',
            'score' => $score,
        );
    }

    usort($matches, function($a, $b) {
        if ($a['score'] === $b['score']) {
            return strcmp($a['street_name'], $b['street_name']);
        }
        return ($a['score'] > $b['score']) ? -1 : 1;
    });

    if ($place_record) {
        $same_place = array();
        foreach ($matches as $match) {
            if ($match['place_id'] === $place_record['id']) {
                $same_place[] = $match;
            }
        }
        if (!empty($same_place)) {
            $matches = $same_place;
        }
    }

    $status = 'not_found';
    $auto_street_id = '';
    if (!empty($matches)) {
        if (count($matches) === 1) {
            $status = 'ok';
            $auto_street_id = $matches[0]['street_id'];
        } else {
            $status = 'ambiguous';
            if ($matches[0]['score'] >= 200) {
                $auto_street_id = $matches[0]['street_id'];
            }
        }
    }

    return array(
        'street_line' => $street_line,
        'street_name' => $street_name,
        'house_no' => $house_no,
        'matches' => $matches,
        'status' => $status,
        'auto_street_id' => $auto_street_id,
    );
}

function omsp_manual_parse_text($order_text) {
    $order_text = omsp_remove_bom($order_text);
    $lines = preg_split('/
?
/', $order_text);
    $entries = array();
    foreach ($lines as $idx => $line) {
        $trimmed = trim($line);
        if ($trimmed === '') {
            continue;
        }
        $entries[] = array('index' => $idx, 'text' => $trimmed);
    }
    if (empty($entries)) {
        return new WP_Error('manual_empty', 'Tekst narudzbine je prazan.');
    }

    $ref = omsp_manual_get_reference_data();
    $used = array();

    $name_entry = $entries[0];
    $used[$name_entry['index']] = true;
    $name = $name_entry['text'];

    $price_entry = null;
    foreach ($entries as $entry) {
        if (isset($used[$entry['index']])) {
            continue;
        }
        if (preg_match('/(\d+[.,]?\d*)\s*(din|rsd)/i', $entry['text'], $match)) {
            $price_entry = $entry;
            $used[$entry['index']] = true;
            break;
        }
    }
    $price_value = '';
    $price_raw = '';
    if ($price_entry) {
        $price_raw = $price_entry['text'];
        $numeric = preg_replace('/[^0-9.,]/', '', $price_entry['text']);
        $numeric = str_replace(' ', '', $numeric);
        $numeric = str_replace('.', '', $numeric);
        $numeric = str_replace(',', '.', $numeric);
        if ($numeric !== '' && is_numeric($numeric)) {
            $price_value = rtrim(rtrim(sprintf('%.2f', (float)$numeric), '0'), '.');
        }
    }

    $phone_entry = null;
    foreach ($entries as $entry) {
        if (isset($used[$entry['index']])) {
            continue;
        }
        if (omsp_line_looks_like_phone($entry['text'])) {
            $phone_entry = $entry;
            $used[$entry['index']] = true;
            break;
        }
    }
    $phone_raw = $phone_entry ? $phone_entry['text'] : '';
    $phone_clean = $phone_entry ? omsp_normalize_phone($phone_entry['text']) : '';

    $zip_city_entry = null;
    foreach ($entries as $entry) {
        if (isset($used[$entry['index']])) {
            continue;
        }
        if (preg_match('/\d{5}/', $entry['text'])) {
            $zip_city_entry = $entry;
            $used[$entry['index']] = true;
            break;
        }
    }
    $zip = '';
    $city_text = '';
    if ($zip_city_entry) {
        $zip_city_line = $zip_city_entry['text'];
        if (preg_match('/^\s*(\d{5})\s+(.+)/', $zip_city_line, $m)) {
            $zip = $m[1];
            $city_text = trim($m[2]);
        } elseif (preg_match('/(.+?)\s+(\d{5})$/', $zip_city_line, $m)) {
            $zip = $m[2];
            $city_text = trim($m[1]);
        } else {
            if (preg_match('/(\d{5})/', $zip_city_line, $m)) {
                $zip = $m[1];
            }
            $city_text = trim(preg_replace('/\d{5}/', '', $zip_city_line));
        }
    }

    $place_detection = omsp_manual_pick_place($zip, $city_text, $ref);
    $place_record = $place_detection['selected'];

    $street_entry = null;
    foreach ($entries as $entry) {
        if (isset($used[$entry['index']])) {
            continue;
        }
        if (!omsp_manual_line_could_be_street($entry['text'])) {
            continue;
        }
        $street_entry = $entry;
        $used[$entry['index']] = true;
        break;
    }

    $street_result = array(
        'street_line' => '',
        'street_name' => '',
        'house_no' => '',
        'matches' => array(),
        'status' => 'not_found',
        'auto_street_id' => '',
    );
    if ($street_entry) {
        $street_result = omsp_manual_match_street($street_entry['text'], $place_record, $ref);
    }

    $unused_entries = array();
    foreach ($entries as $entry) {
        if (!isset($used[$entry['index']])) {
            $unused_entries[] = $entry;
        }
    }
    usort($unused_entries, function($a, $b) {
        return $a['index'] <=> $b['index'];
    });

    $items_start_index = null;
    foreach ($unused_entries as $entry) {
        if (preg_match('/^A\d+[A-Za-z0-9]*/', $entry['text'])) {
            $items_start_index = $entry['index'];
            break;
        }
    }

    $items_lines = array();
    if ($items_start_index !== null) {
        foreach ($unused_entries as $entry) {
            if ($entry['index'] < $items_start_index) {
                continue;
            }
            if (stripos($entry['text'], 'serbia') !== false || stripos($entry['text'], 'srbija') !== false) {
                continue;
            }
            $items_lines.append($entry['text']);
        }
    }

    $items_notes = implode("
", $items_lines);

    $warnings = array();
    if ($place_detection['status'] === 'not_found') {
        $warnings[] = 'Grad nije prepoznat u referentnoj listi. Proverite postanski broj i naziv mesta.';
    } elseif ($place_detection['status'] === 'ambiguous') {
        $warnings[] = 'Vise mesta odgovara unetom nazivu. Molimo potvrdite tacno mesto u padajucem meniju.';
    }
    if ($street_result['status'] === 'not_found') {
        $warnings[] = 'Ulica nije pronadjena u CSV listi. Izaberite tacnu ulicu rucno.';
    } elseif ($street_result['status'] === 'ambiguous') {
        $warnings[] = 'Vise ulica odgovara unetom nazivu. Izaberite tacnu ulicu rucno.';
    }
    if ($phone_clean === '' && $phone_raw === '') {
        $warnings[] = 'Telefon nije pronadjen u tekstu narudzbine.';
    }
    if ($price_value === '') {
        $warnings[] = 'Iznos otkupa nije pronadjen u tekstu narudzbine.';
    }

    return array(
        'name' => $name,
        'zip' => $zip,
        'city_input' => $city_text,
        'place' => $place_record,
        'place_detection' => $place_detection,
        'street_line' => $street_result['street_line'],
        'house_no' => $street_result['house_no'],
        'street_matches' => $street_result['matches'],
        'street_status' => $street_result['status'],
        'auto_street_id' => $street_result['auto_street_id'],
        'phone_raw' => $phone_raw,
        'phone_clean' => $phone_clean,
        'price_raw' => $price_raw,
        'price_value' => $price_value,
        'items_lines' => $items_lines,
        'items_notes' => $items_notes,
        'warnings' => $warnings,
    );
}


function omsp_prepare_enriched_streets($streets, $places_by_id) {
    $enriched = array();
    foreach ($streets as $s) {
        $place = $places_by_id[$s['place_id']] ?? array('name'=>'', 'zip'=>'', 'municipality'=>'');
        $enriched[] = array(
            'street_id' => $s['id'],
            'street_name' => $s['name'],
            'place_id' => $s['place_id'],
            'place_name' => $place['name'],
            'zip' => $place['zip'],
            'municipality' => $place['municipality'],
            'key' => omsp_normalize_street_key($s['name'])
        );
    }
    return $enriched;
}

function omsp_find_best_street_candidate($candidates, $enriched_streets) {
    $best = array('score' => -INF);

    foreach ($candidates as $entry) {
        $line = $entry['text'];
        list($street_for_match, $house_no) = omsp_extract_street_parts($line);
        $candidate_key = omsp_normalize_street_key($street_for_match);
        if ($candidate_key === '') {
            continue;
        }

        $exact = array();
        $partial = array();

        foreach ($enriched_streets as $street_data) {
            if ($street_data['key'] === $candidate_key) {
                $exact[] = $street_data;
            } elseif ($candidate_key !== '' && ($street_data['key'] !== '' && (strpos($street_data['key'], $candidate_key) !== false || strpos($candidate_key, $street_data['key']) !== false))) {
                $partial[] = $street_data;
            }
        }

        if (!empty($exact)) {
            $score = 200 - count($exact);
        } elseif (!empty($partial)) {
            $score = 100 - count($partial);
        } else {
            $score = 0;
        }

        if ($score > $best['score']) {
            $best = array(
                'score' => $score,
                'entry' => $entry,
                'street_for_match' => $street_for_match,
                'house_no' => $house_no,
                'exact' => $exact,
                'partial' => $partial
            );
        }
    }

    if (!isset($best['entry'])) {
        return array(
            'street_line' => '',
            'street_for_match' => '',
            'house_no' => '',
            'matches' => array(),
            'used_index' => null,
            'exact_match' => false
        );
    }

    $matches = !empty($best['exact']) ? $best['exact'] : $best['partial'];
    $exact_match = !empty($best['exact']);

    if (empty($matches) && !omsp_line_seems_like_street($best['entry']['text'])) {
        return array(
            'street_line' => '',
            'street_for_match' => '',
            'house_no' => '',
            'matches' => array(),
            'used_index' => null,
            'exact_match' => false
        );
    }

    return array(
        'street_line' => $best['entry']['text'],
        'street_for_match' => $best['street_for_match'],
        'house_no' => $best['house_no'],
        'matches' => $matches,
        'used_index' => $best['entry']['index'],
        'exact_match' => $exact_match
    );
}

// === CSV Helper Functions ===
function omsp_load_csv_places() {
    $places_path = OMSP_PATH . 'places.csv';
    $places = array();
    if (file_exists($places_path)) {
        if (($handle = fopen($places_path, 'r')) !== FALSE) {
            while (($data = fgetcsv($handle)) !== FALSE) {
                if (count($data) >= 4) {
                    $places[] = array(
                        'id' => trim($data[0]),
                        'name' => trim($data[1]),
                        'municipality' => trim($data[2]),
                        'zip' => trim($data[3])
                    );
                }
            }
            fclose($handle);
        }
    }
    return $places;
}

function omsp_load_csv_streets() {
    $streets_path = OMSP_PATH . 'streets.csv';
    $streets = array();
    if (file_exists($streets_path)) {
        if (($handle = fopen($streets_path, 'r')) !== FALSE) {
            while (($data = fgetcsv($handle)) !== FALSE) {
                if (count($data) >= 3) {
                    $streets[] = array(
                        'id' => trim($data[0]),
                        'name' => trim($data[1]),
                        'place_id' => trim($data[2])
                    );
                }
            }
            fclose($handle);
        }
    }
    return $streets;
}

function omsp_load_csv_municipalities() {
    $municipalities_path = OMSP_PATH . 'municipalities.csv';
    $municipalities = array();
    if (file_exists($municipalities_path)) {
        if (($handle = fopen($municipalities_path, 'r')) !== FALSE) {
            while (($data = fgetcsv($handle)) !== FALSE) {
                if (count($data) >= 2) {
                    $municipalities[] = array(
                        'id' => trim($data[0]),
                        'name' => trim($data[1])
                    );
                }
            }
            fclose($handle);
        }
    }
    return $municipalities;
}

// === Admin meni ===
add_action('admin_menu', 'omsp_admin_menu');
function omsp_admin_menu() {
    add_menu_page('OMS Porudžbine','OMS Porudžbine','manage_woocommerce',OMSP_SLUG,'omsp_render_dashboard','dashicons-clipboard',56);
    add_submenu_page(OMSP_SLUG,'Tekstualna narudžbina','Tekstualna narudžbina','manage_woocommerce',OMSP_SLUG.'-manual','omsp_render_manual_order');
    add_submenu_page(OMSP_SLUG,'Adresnice','Adresnice','manage_woocommerce',OMSP_SLUG.'-labels','omsp_render_labels');
    add_submenu_page(OMSP_SLUG,'API nalozi','API nalozi','manage_woocommerce',OMSP_SLUG.'-accounts','omsp_render_accounts');
    add_submenu_page(OMSP_SLUG,'BEX adrese','BEX adrese','manage_woocommerce',OMSP_SLUG.'-bex','omsp_render_bex_admin');
}

function omsp_admin_nonce_field() { wp_nonce_field('omsp_admin_action', 'omsp_nonce'); }
function omsp_check_admin_nonce() {
    if (!isset($_POST['omsp_nonce']) || !wp_verify_nonce($_POST['omsp_nonce'], 'omsp_admin_action')) wp_die('Nevažeći zahtev (nonce).');
}

// === Dashboard, Pull orders, Mapping functions ===
// [Previous dashboard, pull orders, and mapping functions remain the same...]
function omsp_render_dashboard() {
    if (!current_user_can('manage_woocommerce')) return;
    echo '<div class="wrap"><h1>OMS Porudžbine</h1>';
    try {
        if (isset($_POST['omsp_test_connect'])) {
            omsp_check_admin_nonce();
            $dns = omsp_dns_debug('api.bex.rs');
            list($ok, $msg) = omsp_tcp_can_connect('api.bex.rs', 62503, 5);
            echo '<div class="updated notice"><p><strong>DNS (api.bex.rs):</strong> '.esc_html(json_encode($dns)).'</p></div>';
            echo '<div class="'.($ok?'updated':'error').' notice"><p><strong>TCP 62503:</strong> '.esc_html($msg).'</p></div>';
        }

        if (isset($_POST['omsp_pull_orders'])) { omsp_check_admin_nonce(); $count = omsp_pull_wc_orders_to_labels(); echo '<div class="updated notice"><p>Uvezeno adresnica: '.intval($count).'</p></div>'; }
        if (isset($_POST['omsp_run_now'])) {
            omsp_check_admin_nonce();
            if (omsp_pull_lock_acquire()) {
                try { $count = omsp_pull_wc_orders_to_labels(); echo '<div class="updated notice"><p>Auto-sync gotov: '.intval($count).'</p></div>'; }
                finally { omsp_pull_lock_release(); }
            } else {
                echo '<div class="notice notice-warning"><p>Import već u toku (lock).</p></div>';
            }
        }
        if (!class_exists('WC_Order_Query')) {
            echo '<div class="error notice"><p>WooCommerce nije aktivan!</p></div>';
        } else {
            $args = array('limit'=>50,'orderby'=>'date','order'=>'DESC','status'=>array('processing','on-hold','pending','completed'),'date_created'=>'>' . (new DateTime('-7 days'))->format('Y-m-d H:i:s'));
            $query = new WC_Order_Query($args); $orders = $query->get_orders();
            echo '<p><strong>WooCommerce porudžbine (zadnjih 7 dana):</strong> ' . count($orders) . '</p>';
            global $wpdb; $labels_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}omsp_labels");
            echo '<p><strong>Adresnice u bazi:</strong> ' . intval($labels_count) . '</p>';
        }

        echo '<form method="post">'; omsp_admin_nonce_field(); submit_button('Povuci adresnice iz WooCommerce','primary','omsp_pull_orders'); echo '</form>';
        echo '<form method="post" style="margin-top:8px;">'; omsp_admin_nonce_field(); submit_button('Pokreni auto-sync odmah','secondary','omsp_run_now'); echo '</form>';
        echo '<form method="post" style="margin-top:8px;">'; omsp_admin_nonce_field(); submit_button('Testiraj BEX konekciju (62503)','secondary','omsp_test_connect'); echo '</form>';

        list($def_site,$def_manual) = omsp_get_default_accounts();
        echo '<p><strong>Podrazumevani API (sa sajta):</strong> ' . esc_html(isset($def_site['name']) ? $def_site['name'] : 'nije podešeno') . '</p>';
        echo '<p><strong>Podrazumevani API (ručne):</strong> ' . esc_html(isset($def_manual['name']) ? $def_manual['name'] : 'nije podešeno') . '</p>';
    } catch (Exception $e) {
        echo '<div class="error notice"><p>Greška: ' . esc_html($e->getMessage()) . '</p></div>'; omsp_log_error('Dashboard error', $e->getMessage());
    }
    echo '</div>';
}

function omsp_tcp_can_connect($host, $port, $timeout = 5) {
    $errno = 0; $errstr = '';
    $fp = @fsockopen($host, $port, $errno, $errstr, $timeout);
    if ($fp) { fclose($fp); return array(true, 'OK'); }
    return array(false, "TCP fail ($host:$port): $errstr [$errno]");
}
function omsp_dns_debug($host) {
    $ipv4 = gethostbynamel($host);
    return array('host'=>$host, 'ipv4'=>$ipv4 ?: array());
}

function omsp_pull_wc_orders_to_labels() {
    try {
        if (!class_exists('WC_Order_Query')) { omsp_log_error('WooCommerce not active'); return 0; }
        $args = array('limit'=>50,'orderby'=>'date','order'=>'DESC','status'=>array('processing','on-hold','pending','completed'),'date_created'=>'>' . (new DateTime('-7 days'))->format('Y-m-d H:i:s'));
        $query = new WC_Order_Query($args); $orders = $query->get_orders();

        global $wpdb; $labels = $wpdb->prefix . 'omsp_labels'; $imported = 0; list($def_site) = omsp_get_default_accounts();

        foreach ($orders as $order) {
            if (!($order instanceof WC_Order)) continue;
            $order_id = $order->get_id(); if (!$order_id) continue;

            $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM $labels WHERE order_id = %d LIMIT 1", $order_id));
            if ($exists) continue;

            // COD
            $cod_amount = null; $cod_meta_keys = array('_cod_amount','cod_amount','otkup','_order_cod','_bex_cod');
            foreach ($cod_meta_keys as $mk) {
                try {
                    $val = $order->get_meta($mk, true);
                    if ($val !== '' && $val !== null) {
                        $val = str_replace(array('.', ' '), '', (string)$val);
                        $val = str_replace(',', '.', $val);
                        if (is_numeric($val)) { $cod_amount = (float)$val; break; }
                    }
                } catch (Exception $e) {}
            }
            if ($cod_amount === null) {
                try { if (method_exists($order,'get_payment_method') && $order->get_payment_method()==='cod') $cod_amount = (float)$order->get_total(); } catch (Exception $e) {}
            }

            $phone = omsp_normalize_phone($order->get_billing_phone());
            $billing_full_name  = trim((method_exists($order,'get_billing_first_name')?$order->get_billing_first_name():'') . ' ' . (method_exists($order,'get_billing_last_name')?$order->get_billing_last_name():''));
            $shipping_full_name = trim((method_exists($order,'get_shipping_first_name')?$order->get_shipping_first_name():'') . ' ' . (method_exists($order,'get_shipping_last_name')?$order->get_shipping_last_name():''));

            $city = $order->get_shipping_city() ?: $order->get_billing_city();
            $address1 = $order->get_shipping_address_1() ?: $order->get_billing_address_1();
            $postal_code = $order->get_shipping_postcode() ?: $order->get_billing_postcode();

            $mapping = omsp_try_map_wc_address($city, $address1, $postal_code);
            $data = array(
                'order_id'=>$order_id,'source'=>'woocommerce','api_account'=>isset($def_site['id'])?$def_site['id']:null,
                'recipient_name'=>$billing_full_name ?: $shipping_full_name,
                'address_line1'=>$mapping['valid']?$mapping['mapped_address']:$address1,
                'address_line2'=>$order->get_shipping_address_2() ?: $order->get_billing_address_2(),
                'city'=>$mapping['valid']?$mapping['mapped_city']:$city,
                'postal_code'=>$postal_code,'phone'=>$phone,
                'notes'=>method_exists($order,'get_customer_note')?$order->get_customer_note():'',
                'cod_amount'=>$cod_amount,'house_no'=>$mapping['valid']?$mapping['house_no']:null,
                'municipality_id'=>$mapping['valid']?$mapping['municipality_id']:null,
                'place_id'=>$mapping['valid']?$mapping['place_id']:null,
                'street_id'=>$mapping['valid']?$mapping['street_id']:null,
                'addr_valid'=>$mapping['valid']?1:0,'addr_error'=>$mapping['valid']?null:$mapping['error'],
            );
            $format = array('%d','%s','%s','%s','%s','%s','%s','%s','%s','%s', ($cod_amount===null?'%s':'%f'), '%s','%d','%d','%d','%d','%s');
            $result = $wpdb->insert($labels,$data,$format);
            if ($result!==false) $imported++;
        }
        return $imported;
    } catch (Exception $e) { omsp_log_error('Pull orders failed',$e->getMessage()); return 0; }
}

function omsp_try_map_wc_address($city, $address1, $postal_code = null) {
    global $wpdb;
    $places = $wpdb->prefix . 'omsp_bex_places';
    $streets = $wpdb->prefix . 'omsp_bex_streets';
    $municip = $wpdb->prefix . 'omsp_bex_municipalities';

    $city_clean = trim($city);
    $place_row = $wpdb->get_row($wpdb->prepare(
        "SELECT p.id as place_id, p.municipality_id, m.name as municipality_name 
         FROM $places p JOIN $municip m ON p.municipality_id = m.id 
         WHERE p.name LIKE %s LIMIT 1", '%' . $city_clean . '%'
    ));

    if (!$place_row) {
        return array('valid'=>false,'error'=>'Mesto "'.$city_clean.'" nije pronađeno u BEX bazi');
    }

    $address_clean = trim($address1);
    $street_name = preg_replace('/\s+\d+.*$/', '', $address_clean);
    $house_number = trim(str_replace($street_name, '', $address_clean)) ?: 'BB';

    $street_row = $wpdb->get_row($wpdb->prepare(
        "SELECT id, name FROM $streets WHERE place_id=%d AND name LIKE %s LIMIT 1",
        $place_row->place_id, '%' . $street_name . '%'
    ));

    if (!$street_row) {
        return array('valid'=>false,'error'=>'Ulica "'.$street_name.'" nije pronađena u mestu '.$city_clean);
    }

    return array(
        'valid'=>true,
        'municipality_id'=>$place_row->municipality_id,
        'place_id'=>$place_row->place_id,
        'street_id'=>$street_row->id,
        'house_no'=>$house_number,
        'mapped_address'=>$street_row->name . ' ' . $house_number,
        'mapped_city'=>$city_clean
    );
}

function omsp_remap_invalid_addresses() {
    global $wpdb;
    $labels = $wpdb->prefix . 'omsp_labels';
    $invalid_labels = $wpdb->get_results("SELECT id, city, address_line1, postal_code FROM $labels WHERE addr_valid=0 LIMIT 100");
    $remapped = 0;
    foreach ($invalid_labels as $label) {
        $mapping = omsp_try_map_wc_address($label->city, $label->address_line1, $label->postal_code);
        if ($mapping['valid']) {
            $wpdb->update($labels, array(
                'address_line1'=>$mapping['mapped_address'],'city'=>$mapping['mapped_city'],'house_no'=>$mapping['house_no'],
                'municipality_id'=>$mapping['municipality_id'],'place_id'=>$mapping['place_id'],'street_id'=>$mapping['street_id'],
                'addr_valid'=>1,'addr_error'=>null
            ), array('id'=>$label->id));
            $remapped++;
        }
    }
    return $remapped;
}

function omsp_pull_lock_acquire() { if (get_transient('omsp_pull_lock')) return false; set_transient('omsp_pull_lock',1,120); return true; }
function omsp_pull_lock_release() { delete_transient('omsp_pull_lock'); }
add_filter('cron_schedules','omsp_cron_schedules');
function omsp_cron_schedules($s){ $s['omsp_5min']=array('interval'=>300,'display'=>'OMS: svakih 5 min'); return $s; }
register_activation_hook(__FILE__, function(){ if(!wp_next_scheduled('omsp_cron_pull')) wp_schedule_event(time()+60,'omsp_5min','omsp_cron_pull'); });
register_deactivation_hook(__FILE__, function(){ $ts=wp_next_scheduled('omsp_cron_pull'); if($ts) wp_unschedule_event($ts,'omsp_cron_pull'); });
add_action('omsp_cron_pull','omsp_cron_handler');
function omsp_cron_handler(){ if(!omsp_pull_lock_acquire()) return; try { $n=omsp_pull_wc_orders_to_labels(); omsp_log_error("OMSP CRON: importovano $n",null); } catch (Exception $e){ omsp_log_error('CRON error',$e->getMessage()); } finally { omsp_pull_lock_release(); } }

// === Tekstualna narudžbina sa street-driven selection ===
function omsp_render_manual_order() {
    if (!current_user_can('manage_woocommerce')) return;
    echo '<div class="wrap"><h1>Tekstualna narudžbina</h1>';
    $manual_order_text_value = isset($_POST['manual_order_text']) ? (string)wp_unslash($_POST['manual_order_text']) : '';
    $manual_prefill = array();

    $matching_streets = array();
    $auto_selected_street_id = '';
    $house_no_value = 'BB';
    $place_id_value = '';
    $place_display_value = '';
    $zip_display_value = '';
    $municipality_display_value = '';
    $phone = '';
    $phone_display = 'N/A';
    $price = '';
    $price_display = 'N/A';
    $items_notes = '';
    $items_preview = 'N/A';
    $street_for_summary = '';
    $name = '';
    $parse_result = null;

    if (isset($_POST['parse_manual_order']) && $manual_order_text_value !== '') {
        omsp_check_admin_nonce();
        $order_text = trim($manual_order_text_value);
        $manual_order_text_value = $order_text;

        $parse_result = omsp_manual_parse_text($order_text);

        if (is_wp_error($parse_result)) {
            echo '<div class="error notice"><p>' . esc_html($parse_result->get_error_message()) . '</p></div>';
        } else {
            $name = $parse_result['name'];
            $matching_streets = $parse_result['street_matches'];
            $auto_selected_street_id = $parse_result['auto_street_id'] !== '' ? (string)$parse_result['auto_street_id'] : '';
            $house_no_value = $parse_result['house_no'] !== '' ? $parse_result['house_no'] : 'BB';

            $phone = $parse_result['phone_clean'] !== '' ? $parse_result['phone_clean'] : $parse_result['phone_raw'];
            $phone_display = $phone !== '' ? $phone : 'N/A';

            $price = $parse_result['price_value'];
            $price_display = $price !== '' ? $price . ' din' : 'N/A';

            $items_notes = $parse_result['items_notes'];
            $items_preview = !empty($parse_result['items_lines']) ? implode(', ', array_slice($parse_result['items_lines'], 0, 3)) : 'N/A';

            $place_id_value = '';
            $place_display_value = '';
            $zip_display_value = $parse_result['zip'];
            $municipality_display_value = '';
            if (!empty($parse_result['place'])) {
                $place_id_value = $parse_result['place']['id'];
                $place_display_value = $parse_result['place']['name'];
                $zip_display_value = $parse_result['place']['zip'];
                $municipality_display_value = $parse_result['place']['municipality_name'];
            } else {
                $place_display_value = $parse_result['city_input'];
            }

            $street_for_summary = $parse_result['street_line'] !== '' ? $parse_result['street_line'] : 'N/A';

            $place_summary = 'N/A';
            if (!empty($parse_result['place'])) {
                $place_summary = trim($parse_result['place']['zip'] . ' ' . $parse_result['place']['name']);
            } else {
                $combined_place = trim($parse_result['zip'] . ' ' . $parse_result['city_input']);
                if ($combined_place !== '') {
                    $place_summary = $combined_place;
                }
            }

            if (!empty($parse_result['warnings'])) {
                foreach ($parse_result['warnings'] as $warning_message) {
                    echo '<div class="notice notice-warning"><p>' . esc_html($warning_message) . '</p></div>';
                }
            }

            echo '<div class="notice notice-info"><p><strong>Rezime parsiranja:</strong></p><ul>';
            echo '<li><strong>Ime:</strong> ' . esc_html($name) . '</li>';
            echo '<li><strong>Mesto:</strong> ' . esc_html($place_summary) . '</li>';
            echo '<li><strong>Ulica:</strong> ' . esc_html($street_for_summary) . '</li>';
            echo '<li><strong>Telefon:</strong> ' . esc_html($phone_display) . '</li>';
            echo '<li><strong>Otkup:</strong> ' . esc_html($price_display) . '</li>';
            echo '<li><strong>Stavke:</strong> ' . esc_html($items_preview) . '</li>';
            echo '<li><strong>Broj pronadjenih ulica:</strong> ' . count($matching_streets) . '</li>';
            echo '</ul></div>';

            $manual_prefill = array(
                'recipient_name' => $name,
                'phone' => $phone,
                'cod_amount' => $price,
                'notes' => $items_notes,
                'street_id' => $auto_selected_street_id,
                'house_no' => $house_no_value,
                'place_id' => $place_id_value,
                'place_name' => $place_display_value,
                'postal_code' => $zip_display_value,
                'municipality_name' => $municipality_display_value,
                'api_account' => isset($_POST['api_account']) ? (string)wp_unslash($_POST['api_account']) : '',
            );
        }
    } elseif (isset($_POST['omsp_manual_submit'])) {
        omsp_check_admin_nonce();
        $result = omsp_create_csv_manual_label($_POST);
        $manual_prefill = array(
            'recipient_name' => isset($_POST['recipient_name']) ? (string)wp_unslash($_POST['recipient_name']) : '',
            'phone' => isset($_POST['phone']) ? (string)wp_unslash($_POST['phone']) : '',
            'cod_amount' => isset($_POST['cod_amount']) ? (string)wp_unslash($_POST['cod_amount']) : '',
            'notes' => isset($_POST['notes']) ? (string)wp_unslash($_POST['notes']) : '',
            'street_id' => isset($_POST['street_id']) ? (string)wp_unslash($_POST['street_id']) : '',
            'house_no' => isset($_POST['house_no']) ? (string)wp_unslash($_POST['house_no']) : '',
            'place_id' => isset($_POST['place_id']) ? (string)wp_unslash($_POST['place_id']) : '',
            'place_name' => isset($_POST['place_name_manual']) ? (string)wp_unslash($_POST['place_name_manual']) : '',
            'postal_code' => isset($_POST['postal_code_manual']) ? (string)wp_unslash($_POST['postal_code_manual']) : '',
            'municipality_name' => isset($_POST['municipality_name_manual']) ? (string)wp_unslash($_POST['municipality_name_manual']) : '',
            'api_account' => isset($_POST['api_account']) ? (string)wp_unslash($_POST['api_account']) : ''
        );
        if (is_wp_error($result)) {
            echo '<div class="error notice"><p>' . esc_html($result->get_error_message()) . '</p></div>';
        } else {
            echo '<div class="updated notice"><p>Kreirana adresnica #'.intval($result['label_id']).'</p></div>';
            $manual_prefill = array();
        }
    }
    
    // Show text input form
    echo '<h2>Unesi tekst narudžbine</h2>';
    echo '<p>Format (liniju po liniju):<br>';
    echo '1. Ime i prezime<br>';
    echo '2. Poštanski broj + grad<br>';
    echo '3. Ulica<br>';
    echo '4. Telefon<br>';
    echo '5. Cena (sa "din")<br>';
    echo '6+ Stavke narudžbine</p>';

    $manual_order_placeholder = "Marko Petrović\n11000 Beograd\nKnez Mihailova 42\n0641234567\n2500 din\nMajica XL\nPantalone 32";

    echo '<form method="post">';
    omsp_admin_nonce_field();
    echo '<textarea name="manual_order_text" rows="10" cols="80" placeholder="' . esc_attr($manual_order_placeholder) . '">' . esc_textarea($manual_order_text_value) . '</textarea><br><br>';
    submit_button('Parsiraj narudžbinu', 'primary', 'parse_manual_order');
    echo '</form>';
    
    // Alternative manual entry with street search
    $prefill_recipient = isset($manual_prefill['recipient_name']) ? $manual_prefill['recipient_name'] : '';
    $prefill_street_id = isset($manual_prefill['street_id']) ? $manual_prefill['street_id'] : '';
    $prefill_house_no = isset($manual_prefill['house_no']) && $manual_prefill['house_no'] !== '' ? $manual_prefill['house_no'] : 'BB';
    $prefill_phone = isset($manual_prefill['phone']) ? $manual_prefill['phone'] : '';
    $prefill_cod_amount = isset($manual_prefill['cod_amount']) ? $manual_prefill['cod_amount'] : '';
    $prefill_notes = isset($manual_prefill['notes']) ? $manual_prefill['notes'] : '';
    $prefill_place_name = isset($manual_prefill['place_name']) ? $manual_prefill['place_name'] : '';
    $prefill_postal_code = isset($manual_prefill['postal_code']) ? $manual_prefill['postal_code'] : '';
    $prefill_municipality = isset($manual_prefill['municipality_name']) ? $manual_prefill['municipality_name'] : '';
    $prefill_place_id = isset($manual_prefill['place_id']) ? $manual_prefill['place_id'] : '';

    echo '<h2>Ili unesi direktno</h2>';
    echo '<form method="post">';
    omsp_admin_nonce_field();
    echo '<table class="form-table"><tbody>';
    
    $accounts = omsp_get_accounts();
    list($def_site, $def_manual) = omsp_get_default_accounts();
    $prefill_api_account = '';
    if (!empty($manual_prefill['api_account'])) {
        $prefill_api_account = (string)$manual_prefill['api_account'];
    } elseif (isset($def_manual['id'])) {
        $prefill_api_account = (string)$def_manual['id'];
    }
    echo '<tr><th>API nalog</th><td><select name="api_account"><option value="">— ne šalji —</option>';
    foreach ($accounts as $acc) {
        $sel = ((string)$prefill_api_account === (string)$acc['id']) ? ' selected' : '';
        echo '<option value="'.esc_attr($acc['id']).'"'.$sel.'>'.esc_html($acc['name']).'</option>';
    }
    echo '</select></td></tr>';
    
    echo '<tr><th>Ime i prezime</th><td><input required name="recipient_name" type="text" class="regular-text" value="' . esc_attr($prefill_recipient) . '"></td></tr>';
    
    // Street search and selection
    $all_streets = omsp_load_csv_streets();
    $all_places = omsp_load_csv_places();
    
    echo '<tr><th>Pretraži ulicu</th><td><input type="text" id="street_search" placeholder="Ukucaj ime ulice..." onkeyup="filterStreets()"><br><small>Kucaj ime ulice da se filtriraju opcije</small></td></tr>';
    
    echo '<tr><th>Ulica</th><td><select name="street_id" id="street_select_manual" onchange="updatePlaceFromStreetManual()" required>';
    echo '<option value="">— izaberi ulicu —</option>';
    
    // Group streets by place for better display
    $streets_by_place = array();
    foreach ($all_streets as $street) {
        $place_name = '';
        $zip = '';
        $municipality = '';
        foreach ($all_places as $place) {
            if ($place['id'] == $street['place_id']) {
                $place_name = $place['name'];
                $zip = $place['zip'];
                $municipality = $place['municipality'];
                break;
            }
        }
        $streets_by_place[] = array(
            'street_id' => $street['id'],
            'street_name' => $street['name'],
            'place_id' => $street['place_id'],
            'place_name' => $place_name,
            'zip' => $zip,
            'municipality' => $municipality,
            'display_text' => $street['name'] . ' (' . $place_name . ' ' . $zip . ')',
            'search_text' => strtolower($street['name']),
            'search_key' => omsp_normalize_street_key($street['name'])
        );
    }
    
    // Sort streets alphabetically
    usort($streets_by_place, function($a, $b) {
        return strcmp($a['display_text'], $b['display_text']);
    });
    
    foreach ($streets_by_place as $street_data) {
        $manual_selected = ($prefill_street_id !== '' && (string)$street_data['street_id'] === (string)$prefill_street_id) ? ' selected' : '';
        echo '<option value="' . esc_attr($street_data['street_id']) . '" ';
        echo 'data-place-id="' . esc_attr($street_data['place_id']) . '" ';
        echo 'data-place-name="' . esc_attr($street_data['place_name']) . '" ';
        echo 'data-zip="' . esc_attr($street_data['zip']) . '" ';
        echo 'data-municipality="' . esc_attr($street_data['municipality']) . '" ';
        $search_attr = trim($street_data['search_text'] . ' ' . $street_data['search_key']);
        echo 'data-search-text="' . esc_attr($search_attr) . '"' . $manual_selected . '>';
        echo esc_html($street_data['display_text']);
        echo '</option>';
    }
    echo '</select></td></tr>';
    
    // Place info (auto-filled)
    echo '<tr><th>Mesto</th><td><input name="place_name_manual" type="text" class="regular-text" id="place_display_manual" readonly value="' . esc_attr($prefill_place_name) . '"></td></tr>';
    echo '<tr><th>Poštanski broj</th><td><input name="postal_code_manual" type="text" class="small-text" id="zip_display_manual" readonly value="' . esc_attr($prefill_postal_code) . '"></td></tr>';
    echo '<tr><th>Opština</th><td><input name="municipality_name_manual" type="text" class="regular-text" id="municipality_display_manual" readonly value="' . esc_attr($prefill_municipality) . '"></td></tr>';
    
    echo '<input type="hidden" name="place_id" id="place_id_hidden_manual" value="' . esc_attr($prefill_place_id) . '">';
    
    echo '<tr><th>Broj kuće</th><td><input name="house_no" type="text" class="small-text" value="' . esc_attr($prefill_house_no) . '"></td></tr>';
    echo '<tr><th>Telefon</th><td><input name="phone" type="text" class="regular-text" value="' . esc_attr($prefill_phone) . '"></td></tr>';
    echo '<tr><th>Otkup (din)</th><td><input name="cod_amount" type="number" step="0.01" class="small-text" value="' . esc_attr($prefill_cod_amount) . '"></td></tr>';
    echo '<tr><th>Napomena</th><td><textarea name="notes" class="large-text" rows="3">' . esc_textarea($prefill_notes) . '</textarea></td></tr>';
    echo '</tbody></table>';
    
    submit_button('Kreiraj adresu');
    echo '<input type="hidden" name="omsp_manual_submit" value="1">';
    echo '</form>';
    
    // JavaScript for manual entry
    echo '<script>
    function updatePlaceFromStreetManual() {
        var streetSelect = document.getElementById("street_select_manual");
        if (!streetSelect) {
            return;
        }

        var selectedOption = streetSelect.options[streetSelect.selectedIndex];
        
        if (selectedOption && selectedOption.value) {
            var placeId = selectedOption.getAttribute("data-place-id");
            var placeName = selectedOption.getAttribute("data-place-name");
            var zip = selectedOption.getAttribute("data-zip");
            var municipality = selectedOption.getAttribute("data-municipality");
            
            document.getElementById("place_display_manual").value = placeName || "";
            document.getElementById("zip_display_manual").value = zip || "";
            document.getElementById("municipality_display_manual").value = municipality || "";
            document.getElementById("place_id_hidden_manual").value = placeId || "";
        } else {
            document.getElementById("place_display_manual").value = "";
            document.getElementById("zip_display_manual").value = "";
            document.getElementById("municipality_display_manual").value = "";
            document.getElementById("place_id_hidden_manual").value = "";
        }
    }
    
    function filterStreets() {
        var searchInput = document.getElementById("street_search");
        var streetSelect = document.getElementById("street_select_manual");
        if (!searchInput || !streetSelect) {
            return;
        }

        var searchText = searchInput.value.toLowerCase();
        
        for (var i = 0; i < streetSelect.options.length; i++) {
            var option = streetSelect.options[i];
            if (i === 0) continue; // Skip the first "choose" option
            
            var streetName = option.getAttribute("data-search-text") || "";
            if (streetName.includes(searchText)) {
                option.style.display = "";
            } else {
                option.style.display = "none";
            }
        }
        
        // Reset selection if current option is hidden
        var currentOption = streetSelect.options[streetSelect.selectedIndex];
        if (currentOption && currentOption.style.display === "none") {
            streetSelect.selectedIndex = 0;
            updatePlaceFromStreetManual();
        }
    }
    
    document.addEventListener("DOMContentLoaded", function() {
        updatePlaceFromStreetManual();
    });
    </script>';
    
    // Display CSV file status
    echo '<h3>Status CSV fajlova:</h3>';
    echo '<ul>';
    echo '<li>places.csv: ' . (file_exists(OMSP_PATH . 'places.csv') ? '<span style="color:green">Postoji (' . count(omsp_load_csv_places()) . ' mesta)</span>' : '<span style="color:red">Nedostaje</span>') . '</li>';
    echo '<li>streets.csv: ' . (file_exists(OMSP_PATH . 'streets.csv') ? '<span style="color:green">Postoji (' . count(omsp_load_csv_streets()) . ' ulica)</span>' : '<span style="color:red">Nedostaje</span>') . '</li>';
    echo '<li>municipalities.csv: ' . (file_exists(OMSP_PATH . 'municipalities.csv') ? '<span style="color:green">Postoji (' . count(omsp_load_csv_municipalities()) . ' opština)</span>' : '<span style="color:red">Nedostaje</span>') . '</li>';
    echo '</ul>';
    echo '<p><small>CSV fajlovi treba da budu u direktorijumu: ' . esc_html(OMSP_PATH) . '</small></p>';
    
    echo '</div>';
}

function omsp_create_csv_manual_label($post) {
    try {
        $name = sanitize_text_field($post['recipient_name'] ?? '');
        $street_id = intval($post['street_id'] ?? 0);
        $place_id = intval($post['place_id'] ?? 0);
        $house_no = sanitize_text_field($post['house_no'] ?? 'BB');
        $phone = omsp_normalize_phone(sanitize_text_field($post['phone'] ?? ''));
        $notes = sanitize_textarea_field($post['notes'] ?? '');
        $api_account = sanitize_text_field($post['api_account'] ?? '');
        
        if (empty($name)) return new WP_Error('missing_name','Ime je obavezno.');
        if (empty($street_id)) return new WP_Error('missing_street','Ulica je obavezna.');
        if (empty($place_id)) return new WP_Error('missing_place','Mesto je obavezno.');

        $cod_amount = null;
        if (strlen((string)($post['cod_amount'] ?? ''))) {
            $raw = (string)$post['cod_amount']; 
            $raw = str_replace(array('.', ' '), '', $raw); 
            $raw = str_replace(',', '.', $raw);
            if (is_numeric($raw)) $cod_amount = (float)$raw;
        }

        // Load CSV data to get names
        $places = omsp_load_csv_places();
        $streets = omsp_load_csv_streets();
        $municipalities = omsp_load_csv_municipalities();

        $place_name = '';
        $municipality_id = 0;
        $postal_code = '';
        foreach ($places as $p) {
            if ($p['id'] == $place_id) {
                $place_name = $p['name'];
                $postal_code = $p['zip'];
                // Find municipality ID by name
                foreach ($municipalities as $m) {
                    if ($m['name'] == $p['municipality']) {
                        $municipality_id = intval($m['id']);
                        break;
                    }
                }
                break;
            }
        }

        $street_name = '';
        foreach ($streets as $s) {
            if ($s['id'] == $street_id) {
                $street_name = $s['name'];
                break;
            }
        }

        if (empty($place_name) || empty($street_name)) {
            return new WP_Error('invalid_selection','Nevalidni izbor mesta ili ulice iz CSV fajlova.');
        }

        $address_line1 = $street_name . ' ' . ($house_no ?: 'BB');

        global $wpdb; 
        $labels = $wpdb->prefix . 'omsp_labels';
        $result = $wpdb->insert($labels, array(
            'order_id'=>null,
            'source'=>'manual_csv',
            'api_account'=>$api_account ?: null,
            'recipient_name'=>$name,
            'address_line1'=>$address_line1,
            'address_line2'=>'',
            'city'=>$place_name,
            'postal_code'=>$postal_code,
            'phone'=>$phone,
            'notes'=>$notes,
            'cod_amount'=>$cod_amount,
            'house_no'=>$house_no ?: 'BB',
            'municipality_id'=>$municipality_id,
            'place_id'=>$place_id,
            'street_id'=>$street_id,
            'addr_valid'=>1,
            'addr_error'=>null,
        ), array('%s','%s','%s','%s','%s','%s','%s','%s','%s', 
                  ($cod_amount===null?'%s':'%f'), 
                  '%s','%d','%d','%d','%d','%s'));
        
        if ($result===false) return new WP_Error('db_error','Greška pri snimanju adresnice.');
        $label_id = intval($wpdb->insert_id);
        return array('order_id'=>0,'label_id'=>$label_id);
    } catch (Exception $e) { 
        omsp_log_error('Manual CSV order creation failed',$e->getMessage()); 
        return new WP_Error('creation_error','Greška pri kreiranju.'); 
    }
}

// === API nalozi, BEX admin, and all other functions remain the same... ===
function omsp_render_accounts() {
    if (!current_user_can('manage_woocommerce')) return;
    try {
        if (isset($_POST['omsp_accounts_save'])) {
            omsp_check_admin_nonce();
            $rows = $_POST['acc'] ?? array(); $clean = array();
            foreach ($rows as $row) {
                if (empty($row['name'])) continue;
                $id = sanitize_title($row['id'] ?: $row['name']);
                $pay_type = intval($row['pay_type'] ?? 6);
                if (!in_array($pay_type, array(1,2,6), true)) $pay_type = 6;
                $clean[] = array(
                    'id'=>$id,
                    'name'=>sanitize_text_field($row['name']),
                    'token'=>sanitize_text_field($row['token']),
                    'client_id'=>sanitize_text_field($row['client_id']),
                    'pay_type'=>$pay_type,
                    'senders_account_number'=>sanitize_text_field($row['senders_account_number'] ?? ''),
                    'is_default_site'=>!empty($row['is_default_site']) ? 1 : 0,
                    'is_default_manual'=>!empty($row['is_default_manual']) ? 1 : 0
                );
            }
            update_option(OMSP_OPT_ACCOUNTS, $clean); echo '<div class="updated notice"><p>Sačuvano.</p></div>';
        }

        $accs = omsp_get_accounts();
        echo '<div class="wrap"><h1>API nalozi</h1><form method="post">'; omsp_admin_nonce_field();
        echo '<table class="widefat">';
        echo '<thead><tr><th>ID</th><th>Naziv naloga</th><th>X-Auth-Token</th><th>KlijentID</th><th>Način plaćanja (payType)</th><th>Račun pošiljaoca (sendersAccountNumber)</th><th>Default (sa sajta)</th><th>Default (ručne)</th></tr></thead>';
        echo '<tbody>';

        $rows = max(count($accs)+1,2);
        for ($i=0; $i<$rows; $i++) {
            $a = $accs[$i] ?? array('id'=>'','name'=>'','token'=>'','client_id'=>'','pay_type'=>6,'senders_account_number'=>'','is_default_site'=>0,'is_default_manual'=>0);
            $payType = isset($a['pay_type']) ? intval($a['pay_type']) : 6;
            if (!in_array($payType, array(1,2,6), true)) $payType = 6;

            echo '<tr>';
            echo '<td><input name="acc['.$i.'][id]" value="'.esc_attr($a['id']).'" placeholder="auto"></td>';
            echo '<td><input name="acc['.$i.'][name]" value="'.esc_attr($a['name']).'" class="regular-text"></td>';
            echo '<td><input name="acc['.$i.'][token]" value="'.esc_attr($a['token']).'" class="regular-text"></td>';
            echo '<td><input name="acc['.$i.'][client_id]" value="'.esc_attr($a['client_id']).'" class="regular-text"></td>';

            echo '<td><select name="acc['.$i.'][pay_type]">';
            echo '<option value="1"'.selected($payType,1,false).'>1 – Pošiljalac gotovina</option>';
            echo '<option value="2"'.selected($payType,2,false).'>2 – Primalac gotovina</option>';
            echo '<option value="6"'.selected($payType,6,false).'>6 – Pošiljalac preko računa</option>';
            echo '</select></td>';

            echo '<td><input name="acc['.$i.'][senders_account_number]" value="'.esc_attr($a['senders_account_number'] ?? '').'" class="regular-text" placeholder="npr. 160-123456-12"></td>';

            echo '<td><input type="checkbox" name="acc['.$i.'][is_default_site]" '.(!empty($a['is_default_site'])?'checked':'').'></td>';
            echo '<td><input type="checkbox" name="acc['.$i.'][is_default_manual]" '.(!empty($a['is_default_manual'])?'checked':'').'></td>';
            echo '</tr>';
        }

        echo '</tbody></table>'; submit_button('Sačuvaj','primary','omsp_accounts_save'); echo '</form></div>';
    } catch (Exception $e) {
        echo '<div class="error notice"><p>Greška: ' . esc_html($e->getMessage()) . '</p></div>'; omsp_log_error('Accounts page error',$e->getMessage());
    }
}

// [Continue with all BEX functions, labels rendering, etc. - they remain exactly the same as before]
// BEX admin, CSV import, lock functions, API functions, labels rendering all stay the same...

function omsp_render_bex_admin() {
    if (!current_user_can('manage_woocommerce')) return;
    echo '<div class="wrap"><h1>BEX adrese (opštine, mesta, ulice)</h1>';
    try {
        if (isset($_POST['omsp_bex_download'])) {
            omsp_check_admin_nonce(); $ok = omsp_bex_download_and_import();
            if (is_wp_error($ok)) echo '<div class="error notice"><p>' . esc_html($ok->get_error_message()) . '</p></div>';
            else echo '<div class="updated notice"><p>Uvezeno/Osveženo.</p></div>';
        }
        if (isset($_POST['omsp_bex_recreate'])) { omsp_check_admin_nonce(); omsp_recreate_tables(); echo '<div class="updated notice"><p>Tabele ponovno kreirane.</p></div>'; }
        global $wpdb;
        $municip_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}omsp_bex_municipalities");
        $places_count  = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}omsp_bex_places");
        $streets_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}omsp_bex_streets");
        echo '<p>Trenutno u bazi:</p><ul>';
        echo '<li>Opštine: '.intval($municip_count).'</li>';
        echo '<li>Mesta: '.intval($places_count).'</li>';
        echo '<li>Ulice: '.intval($streets_count).'</li></ul>';
        
        echo '<p>CSV fajlovi u plugin direktorijumu:</p><ul>';
        echo '<li>Municipalities.csv: ' . (file_exists(OMSP_PATH . 'Municipalities.csv') ? '<span style="color:green">Postoji</span>' : '<span style="color:red">Nedostaje</span>') . '</li>';
        echo '<li>Places.csv: ' . (file_exists(OMSP_PATH . 'Places.csv') ? '<span style="color:green">Postoji</span>' : '<span style="color:red">Nedostaje</span>') . '</li>';
        echo '<li>Streets.csv: ' . (file_exists(OMSP_PATH . 'Streets.csv') ? '<span style="color:green">Postoji</span>' : '<span style="color:red">Nedostaje</span>') . '</li>';
        echo '</ul>';
        
        echo '<form method="post">'; omsp_admin_nonce_field();
        echo '<p><button class="button button-primary" name="omsp_bex_download" value="1">Uvezi CSV fajlove</button></p>';
        echo '<p><button class="button" name="omsp_bex_recreate" value="1">Ponovno kreiraj tabele</button></p>';
        echo '<p><small>Traži fajlove: Municipalities.csv, Places.csv, Streets.csv u plugin direktorijumu</small></p>';
        echo '</form>';
    } catch (Exception $e) {
        echo '<div class="error notice"><p>Greška: ' . esc_html($e->getMessage()) . '</p></div>'; omsp_log_error('BEX admin error',$e->getMessage());
    }
    echo '</div>';
}

function omsp_bex_download_and_import() {
    try {
        $csv_files = array(
            'municipalities' => OMSP_PATH . 'Municipalities.csv',
            'places'         => OMSP_PATH . 'Places.csv',
            'streets'        => OMSP_PATH . 'Streets.csv',
        );
        $found_files = array(); $missing = array();
        foreach ($csv_files as $type => $path) {
            if (file_exists($path)) { $found_files[$type] = $path; }
            else { $missing[] = $type; }
        }
        if (!empty($missing)) {
            return new WP_Error('csv_files_missing','Nedostaju: '.implode(', ',$missing).'. Postavi ih u: '.OMSP_PATH);
        }
        return omsp_parse_csv_files($found_files);
    } catch (Exception $e) {
        omsp_log_error('BEX CSV import failed',$e->getMessage());
        return new WP_Error('csv_import_error','Greška pri učitavanju BEX CSV fajlova: '.$e->getMessage());
    }
}
function omsp_parse_csv_files($files) {
    global $wpdb; $total_imported = 0;
    foreach ($files as $type => $file_path) {
        if (!file_exists($file_path) || !is_readable($file_path)) continue;
        $h = fopen($file_path,"r"); if(!$h) continue; $data=array();
        while(($row=fgetcsv($h,1000,","))!==false){ if(!empty($row)) $data[]=$row; } fclose($h);
        $total_imported += omsp_import_csv_data_detailed($type,$data);
    }
    return true;
}
function omsp_import_csv_data_detailed($type,$data) {
    global $wpdb; if (empty($data)) return 0;
    if (count($data)>1 && !is_numeric($data[0][0])) array_shift($data);
    $imported=0;
    if ($type==='municipalities') {
        $t=$wpdb->prefix.'omsp_bex_municipalities';
        foreach($data as $r){ if(count($r)>=2){ $id=intval($r[0]); $name=trim($r[1]); if($id&&$name){ $ex=$wpdb->get_var($wpdb->prepare("SELECT id FROM $t WHERE id=%d",$id)); if($ex)continue; if($wpdb->insert($t,array('id'=>$id,'name'=>$name),array('%d','%s'))) $imported++; }}}
    } elseif ($type==='places') {
        $t=$wpdb->prefix.'omsp_bex_places';
        foreach($data as $r){ if(count($r)>=3){ $id=intval($r[0]); $name=trim($r[1]); $mid=intval($r[2]); $zip=isset($r[3])?trim($r[3]):null; if($id&&$name&&$mid){ $ex=$wpdb->get_var($wpdb->prepare("SELECT id FROM $t WHERE id=%d",$id)); if($ex)continue; if($wpdb->insert($t,array('id'=>$id,'municipality_id'=>$mid,'name'=>$name,'zip'=>$zip),array('%d','%d','%s','%s'))) $imported++; }}}
    } else {
        $t=$wpdb->prefix.'omsp_bex_streets';
        foreach($data as $r){ if(count($r)>=3){ $id=intval($r[0]); $name=trim($r[1]); $pid=intval($r[2]); if($id&&$name&&$pid){ $ex=$wpdb->get_var($wpdb->prepare("SELECT id FROM $t WHERE id=%d",$id)); if($ex)continue; if($wpdb->insert($t,array('id'=>$id,'place_id'=>$pid,'name'=>$name),array('%d','%d','%s'))) $imported++; }}}
    }
    return $imported;
}
function omsp_read_csv_file($file_path) {
    try { $rows=array(); if(($h=fopen($file_path,"r"))!==false){ $first=true; while(($d=fgetcsv($h,1000,","))!==false){ if($first && !empty($d[0])){ $d[0]=omsp_remove_bom($d[0]); $first=false; } if(!empty($d)) $rows[]=$d; } fclose($h);} return $rows; } catch (Exception $e) { omsp_log_error('CSV read failed',$file_path.' - '.$e->getMessage()); return false; }
}
function omsp_recreate_tables() {
    global $wpdb; $charset = $wpdb->get_charset_collate();
    $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}omsp_bex_streets");
    $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}omsp_bex_places");
    $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}omsp_bex_municipalities");
    $municip = $wpdb->prefix . 'omsp_bex_municipalities';
    $places  = $wpdb->prefix . 'omsp_bex_places';
    $streets = $wpdb->prefix . 'omsp_bex_streets';
    $wpdb->query("CREATE TABLE $municip ( id INT UNSIGNED PRIMARY KEY, name VARCHAR(190) NOT NULL, INDEX(name) ) $charset;");
    $wpdb->query("CREATE TABLE $places ( id INT UNSIGNED PRIMARY KEY, municipality_id INT UNSIGNED NOT NULL, name VARCHAR(190) NOT NULL, zip VARCHAR(10) NULL, INDEX(municipality_id), INDEX(name) ) $charset;");
    $wpdb->query("CREATE TABLE $streets ( id INT UNSIGNED PRIMARY KEY, place_id INT UNSIGNED NOT NULL, name VARCHAR(190) NOT NULL, INDEX(place_id), INDEX(name) ) $charset;");
    return true;
}

// === Admin enqueue ===
add_action('admin_enqueue_scripts', function($hook){ if (strpos($hook,'omsp')===false) return; wp_enqueue_script('jquery'); });

// === Admin notices ===
add_action('admin_notices', function(){ if (!class_exists('WooCommerce')) echo '<div class="notice notice-error"><p><strong>OMS Porudžbine:</strong> WooCommerce plugin nije aktivan.</p></div>'; });

// === Settings link ===
add_filter('plugin_action_links_' . plugin_basename(__FILE__), function($links){ $settings_link='<a href="'.admin_url('admin.php?page='.OMSP_SLUG).'">Podešavanja</a>'; array_unshift($links,$settings_link); return $links; });

// === Uninstall cleanup ===
register_uninstall_hook(__FILE__, 'omsp_uninstall');
function omsp_uninstall() {
    global $wpdb;
    $tables = array($wpdb->prefix.'omsp_labels',$wpdb->prefix.'omsp_bex_municipalities',$wpdb->prefix.'omsp_bex_places',$wpdb->prefix.'omsp_bex_streets');
    foreach ($tables as $table) { $wpdb->query("DROP TABLE IF EXISTS $table"); }
    delete_option(OMSP_OPT_ACCOUNTS); delete_option('omsp_api_secret'); delete_transient('omsp_pull_lock'); wp_clear_scheduled_hook('omsp_cron_pull');
}

/* ====================== BEX API: POST (strict keys) + GET label ====================== */

// Split "Ime Prezime" -> [prezime, ime] (BEX: name1=Prezime, name2=Ime)
function omsp_split_name($full) {
    $full = trim((string)$full);
    if ($full === '') return array('', '');
    $parts = preg_split('/\s+/', $full);
    if (count($parts) === 1) return array($parts[0], '');
    $last  = array_pop($parts);
    $first = implode(' ', $parts);
    return array($last, $first);
}

// Token, client_id, pay_type, senders_account iz API naloga
function omsp_bex_get_token_for_label_row($row) {
    $acc_id = $row['api_account'] ?? '';
    if (!$acc_id) return null;
    $acc = omsp_get_account_by_id($acc_id);
    return $acc['token'] ?? null;
}
function omsp_bex_get_client_id_for_label_row($row) {
    $acc_id = $row['api_account'] ?? '';
    if (!$acc_id) return '';
    $acc = omsp_get_account_by_id($acc_id);
    return $acc['client_id'] ?? '';
}
function omsp_bex_get_pay_type_for_label_row($row) {
    $acc_id = $row['api_account'] ?? '';
    if (!$acc_id) return 6;
    $acc = omsp_get_account_by_id($acc_id);
    $pt = isset($acc['pay_type']) ? intval($acc['pay_type']) : 6;
    return in_array($pt, array(1,2,6), true) ? $pt : 6;
}
function omsp_bex_get_senders_account_for_label_row($row) {
    $acc_id = $row['api_account'] ?? '';
    if (!$acc_id) return '';
    $acc = omsp_get_account_by_id($acc_id);
    return $acc['senders_account_number'] ?? '';
}

// Izvuci shipmentId iz api_response JSON-a
function omsp_label_get_shipment_id($row) {
    if (empty($row['api_response'])) return null;
    $j = json_decode($row['api_response'], true);
    if (is_array($j) && isset($j['resp']['shipmentsResultList'][0]['shipmentId']))
        return (int)$j['resp']['shipmentsResultList'][0]['shipmentId'];
    if (is_array($j) && isset($j['shipmentId'])) return (int)$j['shipmentId'];
    if (is_array($j) && isset($j['ShipmentId'])) return (int)$j['ShipmentId'];
    return null;
}

// Kućni broj → int (0 ako BB), te sufiks u "apartment"
function omsp_parse_house_for_payload($raw) {
    $raw = trim((string)$raw);
    if ($raw === '' || strtoupper($raw)==='BB') return array(0, '');
    if (preg_match('/^(\d+)\s*([A-Za-z\/\-0-9]*)$/u', $raw, $m)) {
        $num = intval($m[1]);
        $apt = trim($m[2] ?? '');
        return array($num, $apt);
    }
    return array(0, $raw);
}

// Donesi nazive mesta/ulice po ID (za adressType=1)
function omsp_fetch_place_street_names($place_id, $street_id) {
    global $wpdb; $p=$wpdb->prefix.'omsp_bex_places'; $s=$wpdb->prefix.'omsp_bex_streets';
    $place = $wpdb->get_var($wpdb->prepare("SELECT name FROM $p WHERE id=%d",$place_id));
    $street = $wpdb->get_var($wpdb->prepare("SELECT name FROM $s WHERE id=%d",$street_id));
    return array($place ?: '', $street ?: '');
}

// === Tačan payload (ključevi camelCase, tasks sa "type", "nameType" itd.)
function omsp_build_bex_shipment_from_label_row(array $row) {
    $recipient_full = trim((string)($row['recipient_name'] ?? ''));
    list($rec_last, $rec_first) = omsp_split_name($recipient_full);
    $phone  = trim((string)($row['phone'] ?? ''));
    $notes  = mb_substr(trim((string)($row['notes'] ?? '')), 0, 255);

    $municipality_id = (int)($row['municipality_id'] ?? 0);
    $place_id        = (int)($row['place_id'] ?? 0);
    $street_id       = (int)($row['street_id'] ?? 0);
    list($house_num, $apartment) = omsp_parse_house_for_payload($row['house_no'] ?? '0');

    $client_id = omsp_bex_get_client_id_for_label_row($row);

    // Primalac: adressType=1 (nazivi)
    list($place_name, $street_name) = omsp_fetch_place_street_names($place_id, $street_id);

    // Plaćanje / otkup
    $cod = null;
    if ($row['cod_amount'] !== '' && $row['cod_amount'] !== null) $cod = (float)$row['cod_amount'];
    $payTypeAccount = omsp_bex_get_pay_type_for_label_row($row); // 1,2,6 (default 6)
    $payType        = $payTypeAccount;
    $payToSender    = ($cod && $cod > 0) ? (int)round($cod) : 0;
    $payToSenderViaAccount = ($cod && $cod > 0) ? true : false; // uvek na račun ako ima otkupa
    $sendersAccountNumber  = ($cod && $cod > 0) ? omsp_bex_get_senders_account_for_label_row($row) : "";

    $sender_nameType = ($client_id !== '' ? 3 : 1);
    $sender_name1 = ($client_id !== '' ? $client_id : 'Posiljalac');
    $sender_name2 = ($client_id !== '' ? '' : '');

    $payload = array(
        "shipmentId"           => 0,
        "serviceSpeed"         => 1,
        "shipmentType"         => 1,
        "shipmentCategory"     => 1,
        "shipmentWeight"       => 0,
        "totalPackages"        => 1,
        "invoiceAmount"        => 0,
        "shipmentContents"     => 3,
        "commentPublic"        => $notes,
        "commentPrivate"       => "",
        "personalDelivery"     => false,
        "returnSignedInvoices" => false,
        "returnSignedConfirmation" => false,
        "returnPackage"        => false,
        "payType"              => $payType,               // iz naloga (1/2/6)
        "insuranceAmount"      => 0,                      // uvek 0
        "payToSender"          => $payToSender,           // int
        "payToSenderViaAccount"=> $payToSenderViaAccount, // ako ima otkupa → true
        "sendersAccountNumber" => $sendersAccountNumber,  // obavezno ako ima otkupa
        "bankTransferComment"  => "",
        "tasks" => array(
            // Type=1 Pošiljalac (adressType=3: Place/Street su ID-jevi kao string)
            array(
                "type"          => 1,
                "nameType"      => $sender_nameType,
                "name1"         => $sender_name1,
                "name2"         => $sender_name2,
                "adressType"    => 3,
                "place"         => (string)$place_id,
                "street"        => (string)$street_id,
                "houseNumber"   => 0,
                "apartment"     => "",
                "contactPerson" => "",
                "phone"         => "",
                "date"          => "",
                "timeFrom"      => "07:55",
                "timeTo"        => "14:55",
                "preNotification"=> 0,
                "comment"       => "",
                "parcelShop"    => 0
            ),
            // Type=2 Primalac (adressType=1: nazivi mesta/ulice)
            array(
                "type"          => 2,
                "nameType"      => 1, // fizičko lice
                "name1"         => $rec_last,
                "name2"         => $rec_first,
                "adressType"    => 1,
                "place"         => $place_name,
                "street"        => $street_name,
                "houseNumber"   => $house_num,
                "apartment"     => $apartment,
                "contactPerson" => $recipient_full,
                "phone"         => $phone,
                "date"          => "",
                "timeFrom"      => "",
                "timeTo"        => "",
                "preNotification"=> 60,
                "comment"       => "",
                "parcelShop"    => 0
            ),
        ),
        "reports" => array()
    );

    return $payload;
}

// POST: endpoint na portu 62503
function omsp_bex_post_shipment($label_id) {
    global $wpdb; $labels=$wpdb->prefix.'omsp_labels';

    $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $labels WHERE id=%d",$label_id),ARRAY_A);
    if (!$row) return new WP_Error('not_found','Adresnica ne postoji.');

    $token = omsp_bex_get_token_for_label_row($row);
    if (!$token) return new WP_Error('no_token','Nalog nema X-Auth-Token (podesi u „API nalozi").');

    $shipment = omsp_build_bex_shipment_from_label_row($row);

    // Validacija: ako je otkup > 0 → sendersAccountNumber obavezan
    $cod_amount = ($row['cod_amount'] !== '' && $row['cod_amount'] !== null) ? (float)$row['cod_amount'] : 0;
    if ($cod_amount > 0) {
        $accNo = omsp_bex_get_senders_account_for_label_row($row);
        if (trim($accNo) === '') {
            return new WP_Error('missing_account','Za otkupnu pošiljku je obavezan broj računa pošiljaoca (podesi u „API nalozi").');
        }
    }

    $payload = array("shipmentslist"=>array($shipment));

    $url='https://api.bex.rs:62503/ship/api/Ship/postShipments';
    $args=array(
        'headers'=>array('Accept'=>'*/*','Content-Type'=>'application/json','X-Auth-Token'=>$token),
        'timeout'=>45,
        'httpversion'=>'1.1',
        'redirection'=>0,
        'body'=>wp_json_encode($payload),
    );
    $resp=wp_remote_post($url,$args);
    if (is_wp_error($resp)) return new WP_Error('bex_network','BEX mrežna greška: '.$resp->get_error_message());

    $code=wp_remote_retrieve_response_code($resp); $body_str=wp_remote_retrieve_body($resp);
    $data=json_decode($body_str,true);
    if ($code<200 || $code>=300 || !is_array($data)) {
        omsp_log_error('BEX postShipments bad response', array('code'=>$code,'body'=>$body_str));
        return new WP_Error('bex_bad_response','BEX vraća grešku ili nevažeći JSON (HTTP '.$code.').');
    }
    $res=$data['shipmentsResultList'][0] ?? null;
    if (!$res || empty($res['state'])) {
        $err=$res['err'] ?? ($data['reqerr'] ?? 'Nepoznata greška');
        omsp_log_error('BEX postShipments logical error', array('payload'=>$payload,'resp'=>$data));
        return new WP_Error('bex_error','BEX greška: '.$err);
    }
    $shipmentId=(int)$res['shipmentId'];

    // upiši u DB ceo odgovor (da kasnije izvučemo shipmentId) + markiraj api_sent
    $wpdb->update($labels, array(
        'api_sent'=>1,
        'api_response'=>wp_json_encode(array('req'=>$payload,'resp'=>$data))
    ), array('id'=>$label_id), array('%d','%s'), array('%d'));

    return $shipmentId;
}

// GET: etiketa (PDF) sa integrations.bexexpress.rs
function omsp_bex_stream_label_pdf($token, $shipment_id, $pageSize = 6, $pagePosition = 0, $parcelNo = 0) {
    $base = 'https://integrations.bexexpress.rs/api/Shipments/getLabelWithProperties';
    $url = add_query_arg(array(
        'pageSize'=>(int)$pageSize,'pagePosition'=>(int)$pagePosition,'shipmentId'=>(int)$shipment_id,'parcelNo'=>(int)$parcelNo
    ), $base);
    $args = array('headers'=>array('Accept'=>'*/*','Content-Type'=>'application/json','X-Auth-Token'=>$token),'timeout'=>20);
    $resp = wp_remote_get($url, $args);
    if (is_wp_error($resp)) wp_die('BEX label error: '.$resp->get_error_message());
    $code = wp_remote_retrieve_response_code($resp); $body = wp_remote_retrieve_body($resp);
    if ($code<200 || $code>=300 || !$body) wp_die('BEX label HTTP error: '.$code);
    $data = json_decode($body, true);
    if (!is_array($data) || empty($data['state'])) { $err = $data['err'] ?? 'Nepoznata greška'; wp_die('BEX label API error: '.esc_html($err)); }
    $pdf_b64 = $data['parcelLabel'] ?? ''; if (!$pdf_b64) wp_die('BEX label API: prazan parcelLabel.');
    $pdf = base64_decode($pdf_b64); if ($pdf===false) wp_die('BEX label API: nevažeći Base64.');
    nocache_headers(); header('Content-Type: application/pdf'); header('Content-Disposition: inline; filename="bex-label-'.(int)$shipment_id.'.pdf"'); echo $pdf; exit;
}

/* ====================== UI: Adresnice (POST + GET label + Print) ====================== */

function omsp_render_labels() {
    if (!current_user_can('manage_woocommerce')) return;
    global $wpdb; $labels = $wpdb->prefix . 'omsp_labels';

    // GET: BEX PDF etiketa
    if (isset($_GET['bex_label_id'])) {
        $id = intval($_GET['bex_label_id']);
        $pageSize = isset($_GET['pageSize']) ? intval($_GET['pageSize']) : 6;
        $pagePosition = isset($_GET['pagePosition']) ? intval($_GET['pagePosition']) : 0;
        $parcelNo = isset($_GET['parcelNo']) ? intval($_GET['parcelNo']) : 0;

        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $labels WHERE id=%d",$id),ARRAY_A);
        if (!$row) wp_die('Adresnica ne postoji.');
        $token = omsp_bex_get_token_for_label_row($row);
        if (!$token) wp_die('Nalog nema X-Auth-Token (podesi u „API nalozi").');
        $shipment_id = omsp_label_get_shipment_id($row);
        if (!$shipment_id) wp_die('Za ovu adresnicu nemam shipmentId (pošiljka nije kreirana u BEX-u).');
        omsp_bex_stream_label_pdf($token,$shipment_id,$pageSize,$pagePosition,$parcelNo);
        exit;
    }

    // (Opcioni) print view običnog HTML-a
    if (isset($_GET['print_id'])) {
        $print_id=intval($_GET['print_id']);
        if ($print_id) {
            $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $labels WHERE id=%d",$print_id),ARRAY_A);
            if ($row) {
                nocache_headers();
                echo '<!doctype html><html><head><meta charset="utf-8"><title>Adresnica #'.intval($row['id']).'</title><style>body{font-family:Arial,sans-serif;margin:20px}.card{border:1px solid #ccc;padding:16px;width:360px}h1{font-size:18px;margin:0 0 10px}.line{margin:4px 0}.lbl{color:#555}@media print {.no-print{display:none}}</style></head><body><div class="card">';
                echo '<h1>Adresnica #'.intval($row['id']).'</h1>';
                echo '<div class="line"><span class="lbl">Ime: </span>'.esc_html($row['recipient_name']).'</div>';
                echo '<div class="line"><span class="lbl">Adresa: </span>'.esc_html(trim(($row['address_line1'] ?? '').' '.($row['address_line2'] ?? ''))).'</div>';
                echo '<div class="line"><span class="lbl">Grad: </span>'.esc_html($row['city']).'</div>';
                echo '<div class="line"><span class="lbl">Telefon: </span>'.esc_html($row['phone']).'</div>';
                echo '<div class="line"><span class="lbl">Otkup: </span>'.(($row['cod_amount']!==null && $row['cod_amount']!=='')?number_format((float)$row['cod_amount'],2,',','.'):'—').'</div>';
                echo '<hr><button class="no-print" onclick="window.print()">Štampaj</button></div></body></html>'; exit;
            }
        }
    }

    // POST: Pošalji u BEX (kreiraj pošiljku)
    if (isset($_POST['omsp_bex_post']) && isset($_POST['omsp_label_id'])) {
        omsp_check_admin_nonce();
        $l_id=intval($_POST['omsp_label_id']);
        $result=omsp_bex_post_shipment($l_id);
        if (is_wp_error($result)) echo '<div class="error notice"><p>'.esc_html($result->get_error_message()).'</p></div>';
        else echo '<div class="updated notice"><p>Pošiljka kreirana. ShipmentID: '.intval($result).'.</p></div>';
    }

    try {
        if (isset($_POST['omsp_delete_label'])) { omsp_check_admin_nonce(); $id=intval($_POST['omsp_label_id'] ?? 0); if ($id){ $wpdb->delete($labels,array('id'=>$id),array('%d')); } }

        if (isset($_GET['omsp_export'])) {
            $type=sanitize_text_field($_GET['omsp_export']);
            $ids = isset($_GET['ids']) ? array_filter(array_map('intval', explode(',', $_GET['ids']))) : array();
            if (!empty($ids)) {
                $placeholders = implode(',', array_fill(0, count($ids), '%d'));
                $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM $labels WHERE id IN ($placeholders) ORDER BY id DESC", ...$ids), ARRAY_A);
            } else {
                $rows = $wpdb->get_results("SELECT * FROM $labels ORDER BY id DESC LIMIT 1000", ARRAY_A);
            }
            if ($type==='csv') { omsp_export_csv($rows); return; }
        }

        $rows=$wpdb->get_results("SELECT * FROM $labels ORDER BY id DESC LIMIT 100",ARRAY_A);
        $idsParam = !empty($rows) ? implode(',', array_map(function($r){ return $r['id']; }, $rows)) : '';

        echo '<div class="wrap"><h1>Adresnice</h1><p>';
        echo '<a class="button button-primary" href="'.esc_url(add_query_arg(array('omsp_export'=>'csv','ids'=>$idsParam),admin_url('admin.php?page='.OMSP_SLUG.'-labels'))).'">Izvoz CSV</a>';
        echo '</p>';

        echo '<table class="widefat"><thead><tr><th>ID</th><th>Narudžbina</th><th>Ime</th><th>Adresa</th><th>Grad</th><th>Telefon</th><th>Otkup</th><th>Status</th><th>Akcije</th></tr></thead><tbody>';
        foreach ($rows as $r) {
            echo '<tr>';
            echo '<td>'.intval($r['id']).'</td>';
            echo '<td>'.($r['order_id']?('#'.intval($r['order_id'])):'-').'</td>';
            echo '<td>'.esc_html($r['recipient_name']).'</td>';
            echo '<td>'.esc_html(trim(($r['address_line1']??'').' '.($r['address_line2']??''))).'</td>';
            echo '<td>'.esc_html($r['city']).'</td>';
            echo '<td>'.esc_html($r['phone']).'</td>';
            echo '<td>'.($r['cod_amount']!==null && $r['cod_amount']!=='' ? number_format((float)$r['cod_amount'],2,',','.') : '—').'</td>';
            echo '<td>'.(!empty($r['addr_valid'])?'<span style="color:green">OK</span>':'<span style="color:#a00">NEVALIDNO</span>').'</td>';
            echo '<td>';

            $shipment_id = omsp_label_get_shipment_id($r);
            if (!$shipment_id) {
                echo '<form method="post" style="display:inline;margin-right:6px;">';
                omsp_admin_nonce_field();
                echo '<input type="hidden" name="omsp_label_id" value="'.intval($r['id']).'">';
                echo '<button class="button button-primary" name="omsp_bex_post" value="1">Pošalji u BEX</button>';
                echo '</form>';
            } else {
                $label_url_a6 = esc_url(add_query_arg(array('bex_label_id'=>intval($r['id']),'pageSize'=>6,'pagePosition'=>0,'parcelNo'=>0), admin_url('admin.php?page='.OMSP_SLUG.'-labels')));
                $label_url_a4 = esc_url(add_query_arg(array('bex_label_id'=>intval($r['id']),'pageSize'=>4,'pagePosition'=>0,'parcelNo'=>0), admin_url('admin.php?page='.OMSP_SLUG.'-labels')));
                echo '<a class="button" href="'.$label_url_a6.'" target="_blank" style="margin-right:6px;">BEX etiketa (A6)</a>';
                echo '<a class="button" href="'.$label_url_a4.'" target="_blank" style="margin-right:6px;">BEX etiketa (A4)</a>';
            }

            $print_url = esc_url(add_query_arg(array('print_id'=>intval($r['id'])), admin_url('admin.php?page='.OMSP_SLUG.'-labels')));
            echo ' <a class="button" href="'.$print_url.'" target="_blank" style="margin-right:6px;">Štampa</a>';

            echo '<form method="post" style="display:inline">';
            omsp_admin_nonce_field();
            echo '<input type="hidden" name="omsp_label_id" value="'.intval($r['id']).'">';
            echo '<button class="button-link-delete" name="omsp_delete_label" value="1" onclick="return confirm(\'Obrisati?\')">Obriši</button>';
            echo '</form>';

            echo '</td></tr>';
        }
        echo '</tbody></table></div>';
    } catch (Exception $e) {
        echo '<div class="error notice"><p>Greška: ' . esc_html($e->getMessage()) . '</p></div>'; omsp_log_error('Labels page error',$e->getMessage());
    }
}

// === CSV export ===
function omsp_export_csv($rows) {
    try {
        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=adresnice-'.date('Ymd-His').'.csv');
        $out=fopen('php://output','w');
        fputcsv($out,array('ID','Narudžbina','Ime','Adresa1','Adresa2','Grad','Poštanski','Telefon','Napomena','Otkup'));
        foreach ($rows as $r) {
            fputcsv($out,array($r['id'],$r['order_id'],$r['recipient_name'],$r['address_line1'],$r['address_line2'],$r['city'],$r['postal_code'],$r['phone'],$r['notes'],$r['cod_amount']));
        }
        fclose($out); exit;
    } catch (Exception $e) { omsp_log_error('CSV export failed',$e->getMessage()); wp_die('Greška pri eksportu CSV'); }
}
?>
